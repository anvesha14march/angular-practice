export class Ingrident {
 
constructor(public name:string,public amount:number){}

}