import { Component, OnInit } from '@angular/core';
import { Ingrident } from '../shared/ingerdient.model';

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit {
ingridents:Ingrident[] = [
  new Ingrident('apples',5),
  new Ingrident('tomatoes',10)
];
  constructor() { }

  ngOnInit(): void {
  }
  onIngredientAdded(ingrident:Ingrident){
    this.ingridents.push(ingrident);
  }
}
