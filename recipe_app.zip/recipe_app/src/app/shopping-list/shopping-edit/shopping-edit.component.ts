import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { Ingrident } from 'src/app/shared/ingerdient.model';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit {

@ViewChild('nameInput') nameInputref:ElementRef;
@ViewChild('amountInput') amountInputref:ElementRef;
@Output() ingredientAdded = new EventEmitter<{name:String,amount:number}>();
  constructor() { }

  ngOnInit(): void {
  }
  onAddItem()
  {
    const ingName= this.nameInputref.nativeElement.value;
    const ingAmount =this.amountInputref.nativeElement.value;
const newIngedient = new Ingrident(ingName,ingAmount);
this.ingredientAdded.emit(newIngedient);
  }
}
